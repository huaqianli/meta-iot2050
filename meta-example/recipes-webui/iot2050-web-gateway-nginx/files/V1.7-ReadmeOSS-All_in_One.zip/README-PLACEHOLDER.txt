IOT2050 OSS Clearing placeholder archive
=========================================

This is a FAKE placeholder file for development and UI integration testing.
It is not the official OSS Clearing package.

The official V1.7 OSS Clearing package has not been released yet. After the
official V1.7 release, this fake file will be replaced with the official V1.7
archive before production release.
